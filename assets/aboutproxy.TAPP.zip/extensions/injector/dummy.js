class ExtensionInjectorDummy extends ExtensionInjector {
  constructor(){super()}
  parseManifest(){}
  async injectDOMContentLoaded(){}
  async injectLoaded(){}
}
