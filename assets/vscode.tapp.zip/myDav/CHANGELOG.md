# Change Log (vscode-webdav)

## 1.0.0 (Jan 2023)

* First version of the WebDAV FileSystemProvider
* Support for three different authenttication schemes - Basic, Digest and Windows SSPI (Kerberos)
* Secrets are stored securely in the VS Code SecretStorage
